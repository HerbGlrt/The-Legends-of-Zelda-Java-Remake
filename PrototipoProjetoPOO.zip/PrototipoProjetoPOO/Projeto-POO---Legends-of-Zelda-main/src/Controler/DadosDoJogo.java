package Controler;

import Modelo.Personagem;
import auxiliar.Posicao;
import java.io.Serializable;
import java.util.ArrayList;

// Classe utilizada para captar e configurar os dados do jogo necessários a serem salvos e/ou carregados
public class DadosDoJogo implements Serializable{
    
    Posicao pPosicao;
    public int olhando;           // Qual lado está olhando: Cima(0), Direita(1), Baixo(2), Esquerda(3)
    int vida = 3; // Vida do personagem
    ArrayList<Personagem> fase;
    int[] inimigos1;
    int[] inimigos2;
    int[] inimigos3;
    int[] inimigos4;
}
