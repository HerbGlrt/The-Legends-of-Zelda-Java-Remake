package Auxiliar;

import java.io.File;

public class Consts {
    // CONSTANTES DE CONFIGURACAO GERAL DA TELA
    public static final int CELL_SIDE = 46; // Tamanho de cada celula
    public static final int RES = 16; // Tamanho da janela do jogo
    public static final int PERIOD = 150; // Intervalo de tempo entre cada quadro
    public static final String PATH = File.separator+"imgs"+File.separator; // Diretorio para buscar imagens
    public static final int TIMER = 8;
}